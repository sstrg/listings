package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.*;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;

public class MainActivity extends AppCompatActivity {

    EditText etInput;
    ScriptEngine engine;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etInput = findViewById(R.id.etInput);
        engine = new ScriptEngineManager().getEngineByName("rhino");

        GridLayout gridLayout = findViewById(R.id.gridLayout);
        for (int i = 0; i < gridLayout.getChildCount(); i++) {
            Button btn = (Button) gridLayout.getChildAt(i);

            btn.setOnClickListener(view -> {
                String text = btn.getText().toString();

                switch (text) {
                    case "C":
                        etInput.setText("");
                        break;
                    case "=":
                        try {
                            String input = etInput.getText().toString()
                                    .replace("×", "*")
                                    .replace("÷", "/");
                            Object result = engine.eval(input);
                            etInput.setText(String.valueOf(result));
                        } catch (Exception e) {
                            etInput.setText("Ошибка");
                        }
                        break;
                    default:
                        etInput.append(text);
                }
            });
        }
    }
}